import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
export interface CreateSaltMcpServerOptions {
    registryDir?: string;
    siteBaseUrl?: string;
}
export declare const runCli: (argv?: string[]) => Promise<void>;
export declare const createSaltMcpServer: (options?: CreateSaltMcpServerOptions) => Promise<McpServer>;
