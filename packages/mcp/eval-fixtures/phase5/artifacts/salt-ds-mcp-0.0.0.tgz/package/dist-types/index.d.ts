/// <reference types="node" preserve="true" />
import type { McpServer } from "@modelcontextprotocol/server";
export type ProjectAccessOptions = {
    mode: "restricted";
    allowedRoots: string[];
    defaultRoot?: string;
} | {
    mode: "unrestricted_local_stdio";
    defaultRoot?: string;
};
export interface CreateSaltMcpServerOptions {
    registryDir?: string;
    projectAccess?: ProjectAccessOptions;
}
export declare const runCli: (argv?: string[]) => Promise<void>;
export declare const createSaltMcpServer: (options?: CreateSaltMcpServerOptions) => Promise<McpServer>;
